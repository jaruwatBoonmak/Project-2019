
class GameStart extends Phaser.Scene {
    

    constructor(){
        super('gamePlay');
        var playerSCORE;
    }

    preload() {


        this.animalWords = this.createWords();

        for (var i = 0; i < this.animalWords.length; i++) {
            this.load.audio(this.animalWords[i].key + 'Audio', 'assets/audio/' + this.animalWords[i].key + 'Audio.mp3');
        }
    }



    dropPotion() {
        let roll = this.getRandomInt(100) 
        if (roll >= 0 && roll <= 10) {
            if ( this.health < 3) {
            this.health += 1;
            }
        }

    }

    createWords() {
        let dict = {};
        let words = [];
        let word;
        let asd = this.cache.text.get('wordText').split('\n');
        for (let i = 0; i < asd.length; i++) {
            word = asd[i].split(' ');
            dict = {
                key: word[0],
                thai: word[1]
            };
            words.push(dict);
        }

        return words;
    }
    

    getRandomInt(max) {
        return Math.floor(Math.random() * Math.floor(max));
    }

    generateQuestion(fortune) {
        this.correctAns = this.allWords[this.getRandomInt(this.allWords.length)];
        do {
            this.wrongAns= this.allWords[this.getRandomInt(this.allWords.length)];
        }while(this.wrongAns.key === this.correctAns.key );


        if (fortune === 1) {
            this.Lanswer.setText(this.correctAns.thai);
            this.Ranswer.setText(this.wrongAns.thai);
        } else if (fortune === 0) {
            this.Lanswer.setText(this.wrongAns.thai);
            this.Ranswer.setText(this.correctAns.thai);
        } else {
            this.Lanswer.setText("error");
            this.Ranswer.setText("error");
        }
        this.question.setText(this.correctAns.key);
    }

    init(){

        this.gameEnd = true;
        this.ansButton = [{
            key : 'leftButton',
            setXY : {
                x: 430,
                y: 2500
            },
        }, {
            key: 'rightButton',
            setXY: {
                x: 1160,
                y: 2500
            },
        }];
    
        this.allWords = this.createWords();
        this.enemyAlive = true;
        this.health = 3;
        this.enemy;
        this.ally;

    }
    create(){
        this.anims.create({
            key: 'enemyWalk',
            frames: [
                {key: 'enemyWalk1' },
                {key: 'enemyWalk2' },
                {key: 'enemyWalk3' },
                {key: 'enemyWalk4', duration: 25 }
            ],
            frameRate: 4,
            repeat: -1
        })
        this.anims.create({
            key: 'allyIdle',
            frames: [
                {key: 'allyIdle1' },
                {key: 'allyIdle2' },
                {key: 'allyIdle3' },
                {key: 'allyIdle4' },
                {key: 'allyIdle5' },
                {key: 'allyIdle6' },
                {key: 'allyIdle7' },
                {key: 'allyIdle8' },
                {key: 'allyIdle9' },
                {key: 'allyIdle10', duration: 25 }
            ],
            frameRate: 10,
            repeat: -1
        })
        this.anims.create({
            key: 'allyShoot',
            frames: [
                {key: 'allyShoot1' },
                {key: 'allyShoot2' },
                {key: 'allyShoot3', duration: 25 }
            ],
            frameRate: 3,
        })
        this.anims.create({
            key: 'enemyDie',
            frames: [
                {key: 'enemyDie1' },
                {key: 'enemyDie2' },
                {key: 'enemyDie3' },
                {key: 'enemyDie4' },
                {key: 'enemyDie5' },
                {key: 'enemyDie6' },
                {key: 'enemyDie7' },
                {key: 'enemyDie8', duration: 25 }
            ],
            frameRate: 8
        })
        this.anims.create({
            key: 'allyDie',
            frames: [
                {key: 'allyDie1' },
                {key: 'allyDie2' },
                {key: 'allyDie3' },
                {key: 'allyDie4' },
                {key: 'allyDie5' },
                {key: 'allyDie6' },
                {key: 'allyDie7' },
                {key: 'allyDie8' },
                {key: 'allyDie9' },
                {key: 'allyDie10', duration: 25 }
            ],
            frameRate: 10
        })
        this.anims.create({
            key: 'enemyHit',
            frames: [
                {key: 'enemyHit1'},
                {key: 'enemyHit2'},
                {key: 'enemyHit3', duration: 25}
            ],
            frameRate: 3
        })
        this.anims.create({
            key: 'allyDead',
            frames: [
                {key: 'allyDie10', dutaion: 25}
            ],
            frameRate: 1
        })

        this.enemy = this.add.sprite(1300, 1700, 'enemyWalk1').play('enemyWalk').setScale(8).setDepth(1);
        this.ally = this.add.sprite(200, 1700, 'allyIdle1').play('allyIdle').setDepth(1);
        

        //let playerHIGHSCORE= 0;
        let fortune = this.getRandomInt(2);
        this.add.sprite(0, -300, 'background').setOrigin(0, 0).setScale(1.5);
        this.add.sprite(720, 1680, 'floor').setScale(10).setDepth(1);

        //add pause menu
        this.pauseButton = this.add.image(config.width-150, 150, "pauseGame").setInteractive()
            .on('pointerdown', () => this.actionClickPause()).setScale(1.2);

        // add answer button picture

        
        this.answerButton = this.add.group(this.ansButton);
        this.answerButton.setDepth(1);
        console.log(this.answerButton);

        let ansButtons = this.answerButton.getChildren();

        for (let i = 0; i < ansButtons.length; i++) {

            let answerButton = ansButtons[i];

            answerButton.setInteractive();

            answerButton.alphaTween = this.tweens.add({
                targets: answerButton,
                alpha: 0.7,
                duration: 200,
                paused: true
            });

            answerButton.correctTween = this.tweens.add({
                targets: answerButton,
                scaleX: 1.5,
                scaleY: 1.5,
                duration: 300,
                paused: true,
                yoyo: true,
                ease: 'Quad.easeInOut'
            });

            answerButton.wrongTween = this.tweens.add({
                targets: answerButton,
                scaleX: 1.5,
                scaleY: 1.5,
                duration: 300,
                angle: 90,
                paused: true,
                yoyo: true,
                ease: 'Quad.easeInOut'
            });

            answerButton.on('pointerdown', function(pointer) {

                let result = this.processANS(fortune, this.ansButton[i].key);

                // depending on the result, we'll play one tween or the other
                if(result) {
                    answerButton.correctTween.play();
                    playerSCORE += 1;
                    this.playerScoreText.setText('SCORE: '+playerSCORE);
                    this.dropPotion();
                    if (playerSCORE > playerHIGHSCORE) {
                        playerHIGHSCORE = playerSCORE;
                        checkHighS = true;
                    }
                    this.enemy.play('enemyDie');
                    this.enemy.x = 1300;

                    this.ally.play('allyShoot');
                    this.enemyAlive = false;
                    this.ally.anims.chain('allyIdle');
                    this.enemy.anims.chain('enemyWalk');

                }
                else {
                    answerButton.wrongTween.play();
                    console.log(playerSCORE);
                    this.health -= 1;

                    this.enemy.x = 1300;
                   

                    if (this.health === 0) {
                        this.ally.play('allyDie');
                        this.playerScoreText.setText('SCORE: 0');
                        this.scene.pause();
                        this.scene.launch("endmenu");


                    
                    }

                }
                if(this.health===3){
                    this.life3.setVisible(true);
                    this.life2.setVisible(false);
                    this.life1.setVisible(false);
                    this.life0.setVisible(false);
                }
                if(this.health===2){
                    this.life2.setVisible(true);
                    this.life3.setVisible(false);
                    this.life1.setVisible(false);
                    this.life0.setVisible(false);
                }
                if(this.health===1){
                    this.life1.setVisible(true);
                    this.life2.setVisible(false);
                    this.life3.setVisible(false);
                    this.life0.setVisible(false);
                }
                if(this.health===0){
                    this.life0.setVisible(true);
                    this.life2.setVisible(false);
                    this.life1.setVisible(false);
                    this.life3.setVisible(false);
                }

                if(checkMu){
                    this.sound.play(this.correctAns.key + 'Audio');
                }

                // show next question
                fortune = this.getRandomInt(2);

                this.generateQuestion(fortune);

            }, this);



            answerButton.on('pointerover', function(pointer) {
                answerButton.alphaTween.play();

            }, this);

            // listen to the pointerout event
            answerButton.on('pointerout', function(pointer) {
                //stop alpha tween
                answerButton.alphaTween.stop();

                // set no transparency
                answerButton.alpha = 1;
            }, this);


        }

        this.Lanswer = this.add.text(320, 2430, 'asd', {
            font: '96px Open Sans',
            fill: '#000000'
        });

        this.Ranswer = this.add.text(1060, 2430, ' ', {
            font: '96px Open Sans',
            fill: '#000000'
        });
        this.Lanswer.setOrigin(0.5, 0.5);
        this.Ranswer.setOrigin(0.5, 0.5);

        this.question = this.add.bitmapText(config.width/2, 500, 'font', '', 120);
        this.question.setOrigin( 0.5, 0.5);


        this.playerScoreText = this.add.bitmapText(50, 300, 'font', '', 60, 1);
        




        this.life0 = this.add.image(300, 200, "life0").setScale(9);
        this.life1 = this.add.image(300, 200, "life1").setScale(9);
        this.life2 = this.add.image(300, 200, "life2").setScale(9);
        this.life3 = this.add.image(300, 200, "life3").setScale(9);

        this.life3.setVisible(true);
        this.life2.setVisible(false);
        this.life1.setVisible(false);
        this.life0.setVisible(false);


        this.Lanswer.setDepth(1);
        this.Ranswer.setDepth(1);

        this.generateQuestion(fortune);
    }



    moveX(speed) {
        this.character.setXY.x -= speed;
    }

    actionClickPause(){
        this.scene.launch('pausemenu');
        this.scene.pause();
        
    }
    
    
    update() {
        let speed = 1.9 + (0.08 * playerSCORE);
        if (this.gameEnd || this.enemyAlive) {
            this.enemyMove(speed);
        };
        if (this.enemy.x <= 500) {
            this.booGame = false;
            this.scene.pause();
            this.enemy.play('enemyHit')
            this.ally.play('allyDie');
            this.scene.launch('endmenu');
            playerSCORE = 0;
            this.playerScoreText.setText('SCORE: 0');
            this.gameEnd = false;
        }

    }

    enemyMove(speed) {
        if (speed <= 3.8) {
            this.enemy.x -= speed;
        } else {
            this.enemy.x -= 3.8;
        }
    }

    processANS(fortune, userResponse) {
        if (fortune === 1) {
            // answer is in the left button
           return userResponse === 'leftButton';
        } else if(fortune !== 1) {
            return userResponse === 'rightButton';
        }
    }

}

