class EndMenu extends Phaser.Scene {
    constructor() {
        super("endmenu");
    }

    create(){
        this.background = this.add.graphics( {x : 0, y : 0} );
        this.background.fillStyle('0x000000', 0.4);
        this.background.fillRect(0, 0, config.width, config.height);
        this.background.setScrollFactor(0);

     

        this.endBG = this.add.image(config.width/2, config.height/2-300, "endBG").setScale(1.3);
	    this.endTa = this.add.image(config.width/2, config.height/2-250, "endTa").setScale(1.3);

        if(checkHighS){
            this.highScore = this.add.bitmapText(config.width/2, config.height/2-450, 'font', 'your highscore', 80);
            this.highScore.setOrigin( 0.5, 0.5);
            this.highScore1 = this.add.bitmapText(config.width/2, config.height/2-250, 'font', playerHIGHSCORE, 160);
            this.highScore1.setOrigin( 0.5, 0.5);
        }else{
            this.yourScore = this.add.bitmapText(config.width/2, config.height/2-450, 'font', 'your score', 80);
            this.yourScore.setOrigin( 0.5, 0.5);
            this.yourScore1 = this.add.bitmapText(config.width/2, config.height/2-250, 'font', playerSCORE, 160);
            this.yourScore1.setOrigin( 0.5, 0.5);
            this.highScore = this.add.bitmapText(config.width/2, config.height/2-100, 'font', 'highscore : '+playerHIGHSCORE, 60);
            this.highScore.setOrigin( 0.5, 0.5);
        }
        
        this.pauseH = this.add.image(config.width/2, config.height/2-800, "endH").setScale(1.3);


        this.restartButton = this.add.image(config.width/2+400, config.height/2+200, "restartButton").setInteractive()
            .on('pointerdown', () => this.actionClickReturn() ).setScale(1.4);

        this.menuButton = this.add.image(config.width/2-400, config.height/2+200, "mainMenu").setInteractive()
            .on('pointerdown', () => this.actionClickMenu() ).setScale(1.4);
	    this.tweens.add({
      		targets: this.pauseH,
      		duration: 1000,
      		scaleX: 1.5,
      		scaleY: 1.5,
      		ease: 'Sine.easeInOut',
      		repeat: -1,
      		yoyo: true
    	});


    }

    actionClickReturn(){
        checkHighS = false;
        playerSCORE = 0;
        this.scene.start("Game");
    }

    actionClickMenu(){
        music.stop();
        checkHighS = false;
        this.scene.stop('Game');
        this.scene.start("menu");
    }
}