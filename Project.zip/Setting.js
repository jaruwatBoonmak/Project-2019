class Setting extends Phaser.Scene  {
    constructor() {
        super("setting");
    }

    create(){
        this.background = this.add.graphics( {x : 0, y : 0} );
        this.background.fillStyle('0x000000', 0.4);
        this.background.fillRect(0, 0, config.width, config.height);
        this.background.setScrollFactor(0);
	
	    this.pauseBG = this.add.image(config.width/2, config.height/2-300, "pauseBG").setScale(1.3);
        this.pauseTa = this.add.image(config.width/2, config.height/2-250, "pauseTa").setScale(1.3);

        this.exitButton = this.add.image(config.width/2+560, config.height/2-800, "close").setInteractive()
        .on('pointerdown', () => this.actionClickExit() ).setScale(1.5);
        
        this.music = this.add.image(config.width/2, config.height/2-300, "music").setInteractive()
            .on('pointerdown', () => this.actionClickMute() ).setScale(1.8);
        this.music2 = this.add.image(config.width/2, config.height/2-300, "musicoff").setInteractive()
            .on('pointerdown', () => this.actionClickUnMute() ).setScale(1.8);
        
        if(checkMu){
            this.music.setVisible(true);
            this.music2.setVisible(false);
        }else{
            this.music2.setVisible(true);
            this.music.setVisible(false);
        }


    }


    actionClickExit(){
        this.scene.stop();
    }

    actionClickMute(){
        music.stop();
        this.music.setVisible(false);
        this.music2.setVisible(true);
        checkMu = false;
    }

    actionClickUnMute(){
        music.play();
        this.music.setVisible(true);
        this.music2.setVisible(false);
        checkMu = true;
    }

    
}