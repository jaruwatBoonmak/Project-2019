var config = {
    type: Phaser.AUTO,
    width: 1440,
    height: 3040,
    backgroundColor : 0x000000,
    scene: [Begin,LoaderBootGame, Menu, LoaderInGame, GameStart, PauseMenu, EndMenu, Help, Setting]
};

var game = new Phaser.Game(config);
var playerHIGHSCORE = 0;
var playerSCORE = 0;
var music;
var checkMu = true;
var checkHighS = false;
var allVocabs;

