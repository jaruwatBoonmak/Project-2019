class Menu extends Phaser.Scene {
    constructor() {
        super("menu");
        
    }

    create(){
        music = this.sound.add('theme').setVolume(0.1);
        if(checkMu){
            music.play();
        }
        this.background = this.add.tileSprite(0, 0 ,config.width+700, config.height+800, "backgroundstart").setScale(1.5);
        this.background.setOrigin(0, 0);

        this.logoW = this.add.image(config.width/2, config.height/2-900, "logoword").setScale(2.5);
        this.logoB = this.add.image(config.width/2, config.height/2-600, "logobear").setScale(1.9);

        this.playgameButton = this.add.image(config.width/2, config.height/2+100, "playButton").setInteractive()
            .on('pointerdown', () => this.actionClickPlay() )
            .on('pointerout', () => this.enterButtonRestState() )
            .on('pointerover', () => this.enterButtonHoverState()).setScale(1.5);
        
        this.playgameButton2 = this.add.image(config.width/2, config.height/2+100, "playButton2").setInteractive()
            .on('pointerdown', () => this.actionClickPlay() )
            .on('pointerout', () => this.enterButtonRestState() )
            .on('pointerover', () => this.enterButtonHoverState()).setVisible(false).setScale(1.5);

        this.exitButton = this.add.image(config.width/2+400, config.height/2+800, "Exit").setInteractive()
            .on('pointerdown', () => this.actionClickExit() ).setScale(1.2);
	
        this.aboutButton = this.add.image(config.width/2-400, config.height/2+800,"aboutButton").setInteractive()
            .on('pointerdown', () => this.actionClickAbout() ).setScale(0.9);

        this.setting = this.add.image(config.width/2+600, 100,"setting").setInteractive()
            .on('pointerdown', () => this.actionClickSetting() ).setScale(1);

	    this.tweens.add({
      		targets: this.playgameButton,
      		duration: 1000,
      		scaleX: 2,
      		scaleY: 2,
      		ease: 'Sine.easeInOut',
      		repeat: -1,
      		yoyo: true
    	});
	    this.tweens.add({
      		targets: this.playgameButton2,
      		duration: 1000,
      		scaleX: 2,
      		scaleY: 2,
      		ease: 'Sine.easeInOut',
      		repeat: -1,
      		yoyo: true
    	});

    }

    actionClickExit(){
        music.stop();
        this.scene.stop();
    }
    actionClickAbout() {
        this.scene.launch('helps');
    }
    actionClickSetting() {
        this.scene.launch('setting');
    }

    actionClickPlay() {
        this.scene.start("gamePlay");
    }

    enterButtonHoverState() {
        this.playgameButton2.setVisible(true);
        this.playgameButton.setVisible(false);
    }

    enterButtonRestState() {
        this.playgameButton2.setVisible(false);
        this.playgameButton.setVisible(true);
    }

    update() {
        //this.background.tilePositionX -= 1.2;
    }

}