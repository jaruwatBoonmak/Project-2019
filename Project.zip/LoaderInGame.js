class LoaderInGame extends Phaser.Scene {


    constructor() {
        super("bootstart");
    }

    preload (){

    }

    create(){

        this.scene.start("Game");

    }



}