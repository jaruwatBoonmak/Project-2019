class PauseMenu extends Phaser.Scene  {
    constructor() {
        super("pausemenu");
    }

    create(){
        this.background = this.add.graphics( {x : 0, y : 0} );
        this.background.fillStyle('0x000000', 0.4);
        this.background.fillRect(0, 0, config.width, config.height);
        this.background.setScrollFactor(0);
	
	this.pauseBG = this.add.image(config.width/2, config.height/2-300, "pauseBG").setScale(1.3);
	this.pauseTa = this.add.image(config.width/2, config.height/2-250, "pauseTa").setScale(1.3);
	this.pauseText = this.add.image(config.width/2, config.height/2-250, "pauseText").setScale(1.3);
	this.pauseH = this.add.image(config.width/2, config.height/2-800, "pauseH").setScale(1.3);

        this.resumeButton = this.add.image(config.width/2, config.height/2+200, "resumeButton").setInteractive()
            .on('pointerdown', () => this.actionClickRe() ).setScale(1.4);

        this.restartButton = this.add.image(config.width/2+400, config.height/2+200, "restartButton").setInteractive()
            .on('pointerdown', () => this.actionClickReturn() ).setScale(1.4);

        this.menuButton = this.add.image(config.width/2-400, config.height/2+200, "mainMenu").setInteractive()
            .on('pointerdown', () => this.actionClickMenu() ).setScale(1.4);



    }

    actionClickRe(){
        checkHighS = false;
        this.scene.resume('gamePlay');
        this.scene.stop();
    }

    actionClickReturn(){
        playerSCORE =0;
        this.scene.start("gamePlay");
    }

    actionClickMenu(){
        checkHighS = false;
        music.stop();
        playerSCORE = 0;
        this.scene.stop('gamePlay');
        this.scene.start("menu");
    }
    
}