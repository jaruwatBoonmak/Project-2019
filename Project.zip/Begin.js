class Begin extends Phaser.Scene {
    constructor() {
        super("begin");
    }


    preload (){
        this.load.image('loading1', 'assets/pic/load/loading1.png');


    }

    create(){
        this.scene.start("bootgame");

    }


}