class LoaderBootGame extends Phaser.Scene {


  constructor() {
    super("bootgame");
  }

    init() {
        this.readyCount = 0;
      }


    preload (){
      this.load.text('wordText', 'assets/word.TXT');
      this.load.image("backgroundstart", "assets/pic/background.png");

      this.load.image('Exit', 'assets/pic/exit.png');
      this.load.image('close', 'assets/pic/close.png');

      this.load.image('logobear', 'assets/pic/logobear.png');
      this.load.image('logoword', 'assets/pic/logoword.png');

      this.load.image('resumeButton', 'assets/pic/resume.png');
      this.load.image('aboutButton', 'assets/pic/about.png');
      this.load.image('restartButton', 'assets/pic/return.png');

      this.load.image('pauseGame', 'assets/pic/pause.png');
      this.load.image('setting', 'assets/pic/settings.png');
      this.load.image('music', 'assets/pic/music.png');
      this.load.image('musicoff', 'assets/pic/music_off.png');

      this.load.image('pauseBG', 'assets/pic/pauseMenu/bg.png');
      this.load.image('pauseH', 'assets/pic/pauseMenu/header.png');
      this.load.image('pauseTa', 'assets/pic/pauseMenu/table.png');
      this.load.image('pauseText', 'assets/pic/pauseMenu/text.png');

      this.load.image('endBG', 'assets/pic/endMenu/bg.png');
      this.load.image('endH', 'assets/pic/endMenu/header.png');
      this.load.image('endTa', 'assets/pic/endMenu/table.png');

      this.load.image('life0', 'assets/pic/health/0.png');
      this.load.image('life1', 'assets/pic/health/2.png');
      this.load.image('life2', 'assets/pic/health/4.png');
      this.load.image('life3', 'assets/pic/health/6.png');

      this.load.image('enemyWalk1', 'assets/bearsum/walk1.png');
      this.load.image('enemyWalk2', 'assets/bearsum/walk2.png');
      this.load.image('enemyWalk3', 'assets/bearsum/walk3.png');
      this.load.image('enemyWalk4', 'assets/bearsum/walk4.png');
      this.load.image('floor', 'assets/pic/forrestFllor.png');

      
      this.load.image('background', 'assets/pic/background.png');
      this.load.image('leftButton', 'assets/rectangle.png');
      this.load.image('rightButton', 'assets/rectangle.png');      

      
    
      this.load.image('playButton', 'assets/pic/play.png');
	    this.load.image('playButton2', 'assets/pic/play2.png');






      for(var i = 1; i <= 8; i++) {
        this.load.image('enemyDie' + i, 'assets/bearsum/dead' + i + '.png');
      }
      for(var i = 1; i <= 3; i++) {
        this.load.image('allyShoot' + i, 'assets/adventure_girl/png/Shoot (' + i + ').png');
      }

     for(var i = 1; i <= 10; i++) {
       this.load.image('allyIdle' + i, 'assets/adventure_girl/png/Idle ('+ i + ').png');
     }
      for (var i = 1; i<= 10; i++) {
        this.load.image('allyDie' + i, 'assets/adventure_girl/png/Dead ('+ i + ').png');
      }
      for( var i = 1; i <= 3; i++) {
        this.load.image('enemyHit' + i, 'assets/bearsum/hit' + i + '.png');
      }

      this.load.audio('theme','assets/bgSound/backgroundMenu.ogg');

      this.load.image('mainMenu', 'assets/pic/home.png');



      this.load.bitmapFont('font', 'assets/pic/font/fontgame.png', 'assets/pic/font/fontgame.fnt');

      var width = this.cameras.main.width;
      var height = this.cameras.main.height;

      var progressBar = this.add.graphics();
      var progresBox = this.add.graphics();
      progresBox.fillStyle(0x222222, 0.8);
      progresBox.fillRect(width / 2 - 160, height / 2 - 30, 320, 50);
  
      // loading text
      var loadingText = this.make.text({
        x: width / 2,
        y: height / 2 -70,
        text: 'Loading...',
        style: {
          font: '72px monospace',
          fill: '#ffffff'
        }
      });
      loadingText.setOrigin(0.5, 0.5);
  
      // percent text
      var percenText = this.make.text({
        x: width / 2,
        y: height / 2 - 5,
        text: '0%',
        style: {
          font: '56px monospace',
          fill: '#ffffff'
        }
      });
      percenText.setOrigin(0.5, 0.5);
  
      // loading assets text
      var assetText = this.make.text({
        x: width / 2,
        y: height / 2 + 50,
        text: '',
        style: {
          font: '56px monospace',
          fill: '#ffffff'
        }
      });
      assetText.setOrigin(0.5, 0.5);
  
      // update progress bar
      this.load.on('progress', function (value) {
        percenText.setText(parseInt(value * 100) + '%');
        progressBar.clear();
        progressBar.fillStyle(0xffffff, 1);
        progressBar.fillRect(width / 2 - 150, height / 2 - 20, 300 * value, 30);
      });
  
      // update file progress text
      this.load.on('fileprogress', function (file) {
        assetText.setText('Loading asset: ' + file.key);
      });
  
      // remove progress bar when complete
      this.load.on('complete', function () {
        progresBox.destroy();
        progressBar.destroy();
        assetText.destroy();
        loadingText.destroy();
        percenText.destroy();
        this.ready();
      }.bind(this));


    }

  

    create(){
      this.scene.start("menu");
    }

    ready() {
        this.readyCount++;
        if (this.readyCount === 2) {
            this.scene.start("menu");
    }
  }
}