class Help extends Phaser.Scene {
    constructor() {
        super("helps");
    }

    create(){
        this.background = this.add.graphics( {x : 0, y : 0} );
        this.background.fillStyle('0x000000', 0.4);
        this.background.fillRect(0, 0, config.width, config.height);
        this.background.setScrollFactor(0);

        this.endBG = this.add.image(config.width/2, config.height/2-300, "endBG").setScale(1.3);
        this.endTa = this.add.image(config.width/2, config.height/2-250, "endTa").setScale(1.3);

        this.playerScoreText = this.add.bitmapText(config.width/2-200, config.height/2-500, 'font', 'help', 120, 1);
        this.Ranswer = this.add.text(config.width/2-400, config.height/2-250, 'เลือกคำแปลที่ถูกต้อง', {
            font: '96px Open Sans',
            fill: '#000000'
        });
        this.exitButton = this.add.image(config.width/2+560, config.height/2-800, "close").setInteractive()
            .on('pointerdown', () => this.actionClickExit() ).setScale(1.5);
    }

    actionClickExit(){
        this.scene.stop();
    }
}